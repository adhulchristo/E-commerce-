import "./App.css";

function App() {
  return (
    <>
      <div className="d-flex justify-content-center align-items-center min-vh-100">
        <h1 className="w-50 text-center">Advanced <span className="text-primary">E-commerce Project</span> using React Js Starter File</h1>
      </div>
    </>
  );
}

export default App;
